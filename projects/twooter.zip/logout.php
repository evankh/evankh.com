<?php
	setcookie("handle", "", 0);
?>
<head>
	<meta http-equiv="refresh" content="0; /index.php?login=out" />
</head>