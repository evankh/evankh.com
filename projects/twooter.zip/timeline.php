<!DOCTYPE html>
<?php
//Setup functions
function format_twoot($con, $twoot){
	//Takes a twoot formatted as the result from the gettimeline operator
	echo "<!-- begin procedural content: format_twoot -->\n";
	if (!$twoot["main_original"]){
		//Just a regular old twoot
		echo "<div id=\"".$twoot["main_ID"]."\" class=\"twoot";
		if ($twoot["main_subtwoot"]){
			echo " with-subtwoot";
		}
		echo "\">
	<div class=\"twoot-header\">
	</div>
	<div class=\"twoot-main\">
		<div class=\"author-block\">
			<a class=\"handle\" href=\"timeline.php?twit=".$twoot["main_author"]."\">@".$twoot["main_author"]."</a>
		</div>
		<div class=\"content-block\">
			<p class=\"content\">".$twoot["main_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["main_twooted"]."
		<div id=\"spacer\"></div>
		<div class=\"stat\">
			<a href=\"favorites.php?twoot=".$twoot["main_ID"]."\">
				<img src=\"images/favorite.svg\" width=16px height=16px alt=\"Favorites: \" title=\"Favorites\">
			</a>";
		// Would be much better implemented in Javascript, but I don't know that
		echo "
			<a href=\"favorite.php?twoot=".$twoot["main_ID"]."&referrer=".$_SERVER["REQUEST_URI"]."\">
				<img src=\"images/add-favorite.svg\" width=16px height=16px alt=\"Add Favorite\" title=\"Add Favorite\">
			</a>
			".$twoot["main_favorites"]."
			<a href=\"retwoot.php?twoot=".$twoot["main_ID"]."&referrer=".$_SERVER["REQUEST_URI"]."\">
				<img src=\"images/retwoot.svg\" width=16px height=16px alt=\"Retwoots: \" title=\"Retwoots\">
			</a>
			".$twoot["main_retwoots"]."
		</div>
	</div>
</div>\n";
	} else{
		//Retwoot
		echo "<div id=\"".$twoot["main_ID"]."-rt-".$twoot["rts_ID"]."\" class=\"twoot\">
	<div class=\"twoot-header\" style=\"border-bottom: 1px solid #ccc; padding-bottom: 2%;\">
		Retwooted by <a class=\"handle\" href=\"timeline.php?twit=".$twoot["main_author"]."\">@".$twoot["main_author"]."</a>
	</div>
	<div class=\"twoot-main\" style=\"padding-top: 2%;\">
		<div class=\"author-block\">
			<a class=\"handle\" href=\"timeline.php?twit=".$twoot["rts_author"]."\">@".$twoot["rts_author"]."</a>
		</div>
		<div class=\"content-block\">
			<p class=\"content\">".$twoot["rts_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["rts_twooted"]."
		<div id=\"spacer\"></div>
		<div class=\"stat\">
			<a href=\"favorites.php?twoot=".$twoot["rts_ID"]."\">
				<img src=\"images/favorite.svg\" width=16px height=16px alt=\"Favorites: \" title=\"Favorites\">
			</a>
			".$twoot["rts_favorites"]."
			<img src=\"images/retwoot.svg\" width=16px height=16px alt=\"Retwoots: \" title=\"Retwoots\">
			".$twoot["rts_retwoots"]."
		</div>
	</div>
</div>\n";
	}
	if ($twoot["main_subtwoot"]){
		//subtwoot
		echo "<div id=\"".$twoot["main_ID"]."-sub-".$twoot["sts_ID"]."\" class=\"subtwoot\">
	<div class=\"twoot-header\">
	</div>
	<div class=\"twoot-main\">
		<div class=\"author-block\">
			<a class=\"handle\" href=\"timeline.php?twit=".$twoot["sts_author"]."\">@".$twoot["sts_author"]."</a>
		</div>
		<div class=\"content-block\">
			<p class=\"sub-content\">".$twoot["sts_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["sts_twooted"]."
		<div id=\"spacer\"></div>
		<div class=\"stat\">
			<a href=\"favorites.php?twoot=".$twoot["sts_ID"]."\">
				<img src=\"images/favorite.svg\" width=16px height=16px alt=\"Favorites: \" title=\"Favorites\">
			</a>
			".$twoot["sts_favorites"]."
			<img src=\"images/retwoot.svg\" width=16px height=16px alt=\"Retwoots: \" title=\"Retwoots\">
			".$twoot["sts_retwoots"]."
		</div>
	</div>
</div>\n";
	}
	echo "<!-- end procedural content: format_twoot -->\n";
}
//Fetch data
	$con = mysqli_init();
	$handle = $_GET["twit"];
	mysqli_real_connect($con, "localhost", "root", "", "twooter");
	mysqli_real_query($con, "SELECT * FROM twits WHERE handle=\"$handle\";");
	$result = mysqli_store_result($con);
	$twit = $result->fetch_array(MYSQLI_ASSOC);
	mysqli_real_query($con, "CALL gettimeline(\"$handle\");");
	$timeline = mysqli_store_result($con);
	$array = $timeline->fetch_all(MYSQLI_ASSOC);
?>
<html>
	<head>
		<title>Twooter - <?php echo $twit["nickname"]; ?>'s profile</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="icon" href="images/icon-16.png" sizes="16x16">
		<link rel="icon" href="images/icon-32.png" sizes="32x32">
		<link rel="icon" href="images/icon-48.png" sizes="48x48">
		<link rel="icon" href="images/icon.svg">
		<meta name="theme-color" content="#f035c0">
	</head>
	<body>
		<nav>
			<div id="nav-logo"><a href="index.php"><img width=100% height=100% src="images/logo.svg" alt="T"></a></div>
			<div id="nav-title">Twooter</div>
			<div id="spacer"></div>
			<div id="nav-menu">
				<ul>
					<?php
						if (!isset($_COOKIE["handle"])){
							echo "<li><a class=\"login\" href=\"login.php\">log in</a></li>
					<li><a class=\"signup\" href=\"newuser.php\">sign up</a></li>";
						} else {
							echo "<li><a class=\"login\" href=\"logout.php\">log out</a></li>";
						}
					?>
					
				</ul>
			</div>
		</nav>
		<header>
			<div class="name">
				<a class="nickname" href="timeline.php?twit=<?php echo $twit["handle"]; ?>"><?php echo $twit["nickname"]; ?></a>
				<p class="handle">@<?php echo $twit["handle"]; ?>
				
				<p class="timestamp">Joined <?php echo $twit["joined"]; ?>
				
			</div>
			<div id="spacer"></div>
			<div id="stats">
				<div class="stat">
					<a href=<?php echo "\"following.php?twit=$handle\""; ?>><img src="images/followed.svg" width=32px height=32px title="Following"></a>
					<?php echo $twit["following"]; ?>
					
				</div>
				<div class="stat">
					<a href=<?php echo "\"followers.php?twit=$handle\""; ?>><img src="images/follow.svg" width=32px height=32px title="Followers"></a>
					<?php echo $twit["followers"]; ?>
					
				</div>
				<div class="stat">
					<a href=<?php echo "\"favorites.php?twit=$handle\""; ?>><img src="images/favorite.svg" width=32px height=32px title="Favorites"></a>
					<?php echo $twit["favorites"]; ?>
					
				</div>
				<div class="stat">
					<a href=<?php echo "\"twoots.php?twit=$handle\""; ?>><img src="images/twoot.svg" width=32px height=32px title="Twoots"></a>
					<?php echo $twit["twoots"]; ?>
					
				</div>
			</div>
		</header>
		<?php
		if (isset($_COOKIE["handle"]) && $_COOKIE["handle"] == $handle) {
			echo "<form name=\"twootentry\" action=\"twoot.php?referrer=".$_SERVER["REQUEST_URI"]."\" method=\"post\" class=\"twootentry\">
			<fieldset>
				<legend>Say something...</legend>
				<input type=\"text\" maxlength=\"140\" name=\"twootdata\" placeholder=\"Twoot twoot twoot\" required=\"required\" class=\"textentry\">
				<input type=\"submit\" class=\"signup\" value=\"Twoot\">
			</fieldset>
		</form>\n";
		}
		?>
		<main>
			<?php 
				if ($twit["following"] == 0) {
					echo "<h1>This user isn't following anyone yet.</h1>
			<p>Once they do, we'll have something to show here.\n";
				}
				foreach ($array as $twoot){
					format_twoot($con, $twoot);
				}
			?>
		</main>
		<footer>
			<p>Twooter and site design &copy;2017 Evan Hoffman
		</footer>
	</body>
</html>
<?php mysqli_close($con); ?>