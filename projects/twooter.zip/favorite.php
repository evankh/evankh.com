<?php
	$twoot = $_GET["twoot"];
	if (isset($_COOKIE["handle"])){
		$handle = $_COOKIE["handle"];
		$con = mysqli_init();
		if (!$con){
			echo "MySQL init failed.<p>";
		}
		if(!mysqli_real_connect($con, "localhost", "root", "", "twooter")){
			echo "Connection failed. ".mysqli_connect_error()."<p>";
		}
		mysqli_real_query($con, "CALL favorite(\"$handle\", $twoot);");
		echo mysqli_error($con);
		mysqli_close($con);
	} else {
		echo "Can't favorite - not logged in!";
	}
?>
<head>
	<meta http-equiv="refresh" content="0; <?php echo $_GET["referrer"]; ?>" />
</head>