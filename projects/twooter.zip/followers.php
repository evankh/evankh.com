<!DOCTYPE html>
<?php
//Setup functions
function format_follower($con, $twit){
	//Takes a twoot formatted as the result from the gettimeline operator
	echo "<!-- begin procedural content: format_follower -->\n";
	//mysqli_real_query($con, "CALL getauthorbyid(\"".$twit["follower"]."\");");
	//$result = mysqli_store_result($con);
	//echo mysqli_error($con);
	//$author = $result->fetch_row(MYSQLI_ASSOC);
	echo "<div class=\"follow\">\n";
	echo "	<div class=\"follow-main\">\n";
	echo "		<a class=\"handle\" href=\"timeline.php?twit=", $twit["follower"], "\">@", $twit["follower"], "</a>\n";
	echo "	</div>\n";
	echo "	<div class=\"follow-footer\">\n";
	echo "			<p class=\"timestamp\">", $twit["followed"], "\n";
	echo "	</div>\n";
	echo "</div>\n";
	echo "<!-- end procedural content: format_follower -->\n";
}
//Fetch data
	$con = mysqli_init();
	$handle = $_GET["twit"];
	mysqli_real_connect($con, "localhost", "root", "", "twooter");
	mysqli_real_query($con, "SELECT * FROM twits WHERE handle=\"$handle\";");
	$result = mysqli_store_result($con);
	$twit = $result->fetch_array(MYSQLI_ASSOC);
	mysqli_real_query($con, "CALL getfollowers(\"$handle\");");
	$followers = mysqli_store_result($con);
	$array = $followers->fetch_all(MYSQLI_ASSOC);
?>
<html>
	<head>
		<title>Twooter - Who is following <?php echo $twit["nickname"]; ?></title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="icon" href="images/icon-16.png" sizes="16x16">
		<link rel="icon" href="images/icon-32.png" sizes="32x32">
		<link rel="icon" href="images/icon-48.png" sizes="48x48">
		<link rel="icon" href="images/icon.svg">
		<meta name="theme-color" content="#f035c0">
	</head>
	<body>
		<nav>
			<div id="nav-logo"><a href="index.php"><img width=100% height=100% src="images/logo.svg" alt="T"></a></div>
			<div id="nav-title">Twooter</div>
			<div id="spacer"></div>
			<div id="nav-menu">
				<ul>
					<?php
						if (!isset($_COOKIE["handle"])){
							echo "
				<li><a class=\"login\" href=\"login.php\">log in</a></li>
				<li><a class=\"signup\" href=\"newuser.php\">sign up</a></li>";
						} else {
							echo "
				<li><a class=\"login\" href=\"logout.php\">log out</a></li>";
						}
					?>
				</ul>
			</div>
		</nav>
		<header>
			<div class="name">
				<a class="nickname" href="timeline.php?twit=<?php echo $twit["handle"]; ?>"><?php echo $twit["nickname"]; ?></a>
				<p class="handle">@<?php echo $twit["handle"]; ?>
				<p class="timestamp">Joined <?php echo $twit["joined"]; ?>
			</div>
			<div id="spacer"></div>
			<div id="stats">
				<div class="stat">
					<a href=<?php echo "\"following.php?twit=$handle\""; ?>><img src="images/followed.svg" width=32px height=32px title="Following"></a>
					<?php echo $twit["following"]; ?>
				</div>
				<div class="stat">
					<a href=<?php echo "\"followers.php?twit=$handle\""; ?>><img src="images/follow.svg" width=32px height=32px title="Followers"></a>
					<?php echo $twit["followers"]; ?>
				</div>
				<div class="stat">
					<a href=<?php echo "\"favorites.php?twit=$handle\""; ?>><img src="images/favorite.svg" width=32px height=32px title="Favorites"></a>
					<?php echo $twit["favorites"]; ?>
				</div>
				<div class="stat">
					<a href=<?php echo "\"twoots.php?twit=$handle\""; ?>><img src="images/twoot.svg" width=32px height=32px title="Twoots"></a>
					<?php echo $twit["twoots"]; ?>
				</div>
			</div>
		</header>
		<main>
			<h1>
				<?php
					if (count($array) > 0) {
						echo $twit["nickname"]."'s followers:";
					} else {
						echo $twit["nickname"]." has no followers yet.";
					}
				?>
			</h1>
			<?php 
	foreach ($array as $follow){
		format_follower($con, $follow);
	}
			?>
		</main>
		<footer>
			<p>Twooter and site design &copy;2017 Evan Hoffman
		</footer>
	</body>
</html>
<?php mysqli_close($con); ?>