<!DOCTYPE html>
<html>
	<head>
		<title>Twooter - A totally original social network - Sign up today!</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="icon" href="images/icon-16.png" sizes="16x16">
		<link rel="icon" href="images/icon-32.png" sizes="32x32">
		<link rel="icon" href="images/icon-48.png" sizes="48x48">
		<link rel="icon" href="images/icon.svg">
		<meta name="theme-color" content="#f035c0">
	</head>
	<body>
		<nav>
			<div id="nav-logo"><a href="index.php"><img width=100% height=100% src="images/logo.svg" alt="T"></a></div>
			<div id="nav-title">Twooter</div>
			<div id="spacer"></div>
			<div id="nav-menu">
				<ul>
					<?php
						if (!isset($_COOKIE["handle"])){
							echo "
				<li><a class=\"login\" href=\"login.php\">log in</a></li>
				<li><a class=\"signup\" href=\"newuser.php\">sign up</a></li>";
						} else {
							echo "
				<li><a class=\"login\" href=\"logout.php\">log out</a></li>";
						}
					?>
				</ul>
			</div>
		</nav>
		<header>
			<div id="header-img"><img width=100px height=100px src="images/logo.svg" alt="Twooter logo"></div>
			<div id="header-title">Twooter</div>
		</header>
		<main>
			<h1>Welcome to twooter!</h1>
			<p>Twooter is a totally original social network, unlike anything else out there on the market.
			<p>Twooter allows you to post messages up to 140 characters in length, which can be seen by your followers
			<p>You can follow other twits to see their twoots.
			<form name="returning" action="login.php" method="post">
				<fieldset>
					<legend>Returning twits...</legend>
					<?php if(isset($_GET["login"])){
						if ($_GET["login"] == "fail"){
							echo "<div style=\"color: #f03510;\">Login failed!</div>";
						}
						if ($_GET["login"] == "out"){
							echo "<div style=\"color: #35f010;\">Successfully logged out.</div>";
						}
					} ?>
					<input type="text" maxlength="30" name="username" placeholder="handle..." class="textentry">
					<input type="submit" class="login" value="log in">
				</fieldset>
			</form>
			<form name="signup" action="newtwit.php" method="post">
				<fieldset>
					<legend>New twits...</legend>
					<?php if(isset($_GET["login"])){
						if ($_GET["login"] == "createfail"){
							echo "<div style=\"color: #f03510;\">Username already exists!</div>";
						}
					} ?>
					<input type="text" maxlength="30" name="username" placeholder="handle..." required="required" class="textentry" id="username">
					<input type="text" maxlength="30" name="realname" placeholder="Real Name..." required="required" class="textentry" id="realname">
					<input type="submit" class="signup" value="sign up">
				</fieldset>
			</form>
		</main>
		<footer>
			<p>Twooter and site design &copy;2017 Evan Hoffman
		</footer>
	</body>
</html>