<!DOCTYPE html>
<html>
	<head>
<?php
function clear_results($con) {
	while ($con->next_result()){
		if ($lresult=$con->store_result()) {
			mysqli_free_result($lresult);
		}
	}
}
	//Setup connection
	$con = mysqli_init();
	if (!$con){
		echo "MySQL init failed.<p>";
	}
	if(!mysqli_real_connect($con, "localhost", "root", "", "twooter")){
		echo "Connection failed. ".mysqli_connect_error()."<p>";
	}
	if (isset($_POST["username"])){
		$handle = $_POST["username"];
		$realname = $_POST["realname"];
		//Query database
		//mysqli_real_query($con, "SELECT * FROM twits WHERE handle=\"$handle\";");
		mysqli_real_query($con, "CALL getauthorbyid(\"$handle\");");
		$twit = mysqli_use_result($con);
		//echo $twit;
		if (!$twit) {
			echo "Couldn't fetch from database.<p>";
		}
		$row = $twit->fetch_row();
		if ($row[0] == $handle) {
			echo "Can't create user; already exists";
			$success = False;
		} else {
			clear_results($con);
			mysqli_real_query($con, "CALL newtwit(\"$handle\", \"$realname\")");
			setcookie("handle", $handle, time()+3600);
			$success = True;
		}
		echo "
		<meta http-equiv=\"refresh\" content=\"0;";
			if ($success){
				echo "timeline.php?twit=".$handle;
			} else {
				echo "index.php?login=createfail";
			}
			echo "\" />";
	}
?>
		<title>Twooter - Log in</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="icon" href="images/icon-16.png" sizes="16x16">
		<link rel="icon" href="images/icon-32.png" sizes="32x32">
		<link rel="icon" href="images/icon-48.png" sizes="48x48">
		<link rel="icon" href="images/icon.svg">
		<meta name="theme-color" content="#f035c0">
	</head>
	<body>
		<nav>
			<div id="nav-logo"><a href="index.php"><img width=100% height=100% src="images/logo.svg" alt="T"></a></div>
			<div id="nav-title">Twooter</div>
			<div id="spacer"></div>
			<div id="nav-menu">
				<ul><?php
					if (!isset($_COOKIE["handle"])){
						echo "
					<li><a class=\"login\" href=\"login.php\">log in</a></li>
					<li><a class=\"signup\" href=\"newuser.php\">sign up</a></li>
";
					} else {
						echo "
					<li><a class=\"login\" href=\"logout.php\">log out</a></li>
";
					}?>
				</ul>
			</div>
		</nav>
		<header>
			<div id="header-img"><img width=100px height=100px src="images/logo.svg" alt="Twooter logo"></div>
			<div id="header-title">Twooter</div>
		</header>
		<main>
			<form name="signup" method="post">
				<fieldset>
					<legend>New twits...</legend>
					<input type="text" maxlength="30" name="username" placeholder="handle..." required="required" class="textentry" id="username">
					<input type="text" maxlength="30" name="realname" placeholder="Real Name..." required="required" class="textentry" id="realname">
					<input type="submit" class="signup" value="sign up">
				</fieldset>
			</form>
		</main>
		<footer>
			<p>Twooter and site design &copy;2017 Evan Hoffman
		</footer>
	</body>
</html>
<?php mysqli_close($con); ?>