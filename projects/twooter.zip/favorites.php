<!DOCTYPE html>
<?php
//Setup functions
function clear_results($con) {
	while ($con->next_result()){
		if ($lresult=$con->store_result()) {
			mysqli_free_result($lresult);
		}
	}
}
function format_twoot($con, $twoot){
	//Takes a twoot formatted as the result from the gettimeline operator
	echo "<!-- begin procedural content: format_twit -->\n";
	//mysqli_real_query($con, "CALL getauthorbyid(\"".$twoot["main_author"]."\");");
	//$result = mysqli_store_result($con);
	//echo mysqli_error($con);
	//$author = $result->fetch_row(MYSQLI_ASSOC);
	if (!$twoot["main_original"]){
		//Just a regular old twoot
		echo "<div id=\"".$twoot["main_ID"]."\" class=\"twoot\"";
		if ($twoot["main_subtwoot"]){
			echo " style=\"border-bottom: none; border-radius: 5px 5px 0 0;\"";
		}
		echo ">
	<div class=\"twoot-header\">
	</div>
	<div class=\"twoot-main\">
		<div class=\"author-block\">
			<a class=\"author\">".$twoot["main_author"]."</a>
		</div>
		<div class=\"content-block\">
			<p class=\"content\">".$twoot["main_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["main_twooted"]."
	</div>
</div>\n";
	} else {
		//Retwoot
		echo "<div id=\"".$twoot["rts_ID"]."\" class=\"twoot\">
	<div class=\"twoot-header\" style=\"border-bottom: 1px solid #ccc;\">
		<a class=\"author\">Retwooted by ".$twoot["main_author"]."</a>
	</div>
	<div class=\"twoot-main\">
		<div class=\"author-block\">
			<p class=\"author\">".$twoot["rts_author"]."
		</div>
		<div class=\"content-block\">
			<p class=\"content\">".$twoot["rts_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["rts_twooted"]."
	</div>
</div>\n";
	}
	if ($twoot["main_subtwoot"]){
		//subtwoot
		echo "<div id=\"sub-".$twoot["sts_ID"]."\" class=\"subtwoot\">
	<div class=\"twoot-header\">
	</div>
	<div class=\"twoot-main\">
		<div class=\"author-block\">
			<a class=\"sub-author\">".$twoot["sts_author"]."</a>
		</div>
		<div class=\"content-block\">
			<p class=\"sub-content\">".$twoot["sts_content"]."
		</div>
	</div>
	<div class=\"twoot-footer\">
		<p class=\"timestamp\">".$twoot["sts_twooted"]."
	</div>
</div>\n";
	}
	echo "<!-- end procedural content: format_twit -->\n";
}
function format_favoriter($con, $twit) {
	echo "<!-- begin procedural content: format_favoriter -->\n";
	//mysqli_real_query($con, "CALL getauthorbyid(\"".$twit["follower"]."\");");
	//$result = mysqli_store_result($con);
	//echo mysqli_error($con);
	//$author = $result->fetch_row(MYSQLI_ASSOC);
	echo "<div class=\"follow\">
	<div class=\"follow-main\">
		<a class=\"handle\" href=\"timeline.php?twit=".$twit["twit"]."\">@".$twit["twit"]."</a>
	</div>
	<div class=\"follow-footer\">
			<p class=\"timestamp\">".$twit["favorited"]."
	</div>
</div>\n";
	echo "<!-- end procedural content: format_favoriter -->\n";
}
//Fetch data
	$con = mysqli_init();
	mysqli_real_connect($con, "localhost", "root", "", "twooter");
	if (array_key_exists("twit", $_GET)) {
		$method = "twit";
		$handle = $_GET["twit"];
		mysqli_real_query($con, "SELECT * FROM twits WHERE handle=\"$handle\";");
		$result = mysqli_store_result($con);
		$twit = $result->fetch_array(MYSQLI_ASSOC);
	} else {
		$method = "twoot";
		$twootID = $_GET["twoot"];
		mysqli_real_query($con, "CALL gettwootbyid($twootID);");
		$result = mysqli_store_result($con);
		$twoot = $result->fetch_array(MYSQLI_ASSOC);
	}
	clear_results($con);
	if ($method == "twit") {
		mysqli_real_query($con, "CALL gettwitfavorites(\"$handle\");");
	} else {
		mysqli_real_query($con, "CALL gettwootfavorites($twootID);");
	}
	$favorites = mysqli_store_result($con);
	echo mysqli_error($con);
	$array = $favorites->fetch_all(MYSQLI_ASSOC);
?>
<html>
	<head>
		<title>Twooter - <?php
			if ($method == "twit") {
				echo $twit["nickname"]."'s favorites";
			} else {
				echo "Twits who like this twoot";
			}
		?></title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/styles.css">
		<link rel="icon" href="images/icon-16.png" sizes="16x16">
		<link rel="icon" href="images/icon-32.png" sizes="32x32">
		<link rel="icon" href="images/icon-48.png" sizes="48x48">
		<link rel="icon" href="images/icon.svg">
		<meta name="theme-color" content="#f035c0">
	</head>
	<body>
		<nav>
			<div id="nav-logo"><a href="index.php"><img width=100% height=100% src="images/logo.svg" alt="T"></a></div>
			<div id="nav-title">Twooter</div>
			<div id="spacer"></div>
			<div id="nav-menu">
				<ul>
					<?php
						if (!isset($_COOKIE["handle"])){
							echo "
				<li><a class=\"login\" href=\"login.php\">log in</a></li>
				<li><a class=\"signup\" href=\"newuser.php\">sign up</a></li>";
						} else {
							echo "
				<li><a class=\"login\" href=\"logout.php\">log out</a></li>";
						}
					?>
				</ul>
			</div>
		</nav>
		<header
		<?php
			if ($method == "twit") {
				echo ">
				<div class=\"name\">
					<a class=\"nickname\" href=\"timeline.php?twit=".$twit["handle"]."\">".$twit["nickname"]."</a>
					<p class=\"handle\">@".$twit["handle"]."
					<p class=\"timestamp\">Joined ".$twit["joined"]."
				</div>
				<div id=\"spacer\"></div>
				<div id=\"stats\">
					<div class=\"stat\">
						<a href=\"following.php?twit=".$handle."\"><img src=\"images/followed.svg\" width=32px height=32px title=\"Following\"></a>
						".$twit["following"]."
					</div>
					<div class=\"stat\">
						<a href=\"followers.php?twit=".$handle."\"><img src=\"images/follow.svg\" width=32px height=32px title=\"Followers\"></a>
						".$twit["followers"]."
					</div>
					<div class=\"stat\">
						<a href=\"favorites.php?twit=".$handle."\"><img src=\"images/favorite.svg\" width=32px height=32px title=\"Favorites\"></a>
						".$twit["favorites"]."
					</div>
					<div class=\"stat\">
						<a href=\"twoots.php?twit=".$handle."\"><img src=\"images/twoot.svg\" width=32px height=32px title=\"Twoots\"></a>
						".$twit["twoots"]."
					</div>
				</div>\n";
			} else {
				echo "style=\"display: block;\">";
				format_twoot($con, $twoot);
			}
		?>
		</header>
		<main>
			<?php
				if ($method == "twit") {
					if (count($array) > 0) {
						echo "<h1>".$twit["nickname"]."'s favorites:</h1>";
					} else {
						echo "<h1>".$twit["nickname"]." has no favorites yet.</h1>";
					}
				} else {
					if (count($array) > 0) {
						echo "<h1>Favorited by:</h1>";
					} else {
						echo "<h1>No one has favorited this twoot yet.</h1>";
					}
				}
				foreach ($array as $entry) {
					if ($method == "twit") {
						format_twoot($con, $entry);
					} else {
						format_favoriter($con, $entry);
					}
				}
			?>
		</main>
		<footer>
			<p>Twooter and site design &copy;2017 Evan Hoffman
		</footer>
	</body>
</html>
<?php mysqli_close($con); ?>