<!DOCTYPE php>
<?php
	$twoot = $_POST["twootdata"];
	if (isset($_COOKIE["handle"])){
		$handle = $_COOKIE["handle"];
		$con = mysqli_init();
		if (!$con){
			echo "MySQL init failed.<p>";
		}
		if(!mysqli_real_connect($con, "localhost", "root", "", "twooter")){
			echo "Connection failed. ".mysqli_connect_error()."<p>";
		}
		if (isset($_POST["method"]) && $_POST["method"] == "sub") {
			$subtwoot = $_POST["subtwoot"];
			mysqli_real_query($con, "CALL subtwoot(\"$handle\", $subtwoot, \"$twoot\");");
		} else {
			mysqli_real_query($con, "CALL twoot(\"$handle\", \"$twoot\");");
		}
		mysqli_close($con);
	} else {
		echo "Can't twoot - not logged in!";
	}
?>
<head>
	<meta http-equiv="refresh" content="0;  <?php echo $_GET["referrer"]; ?>" />
</head>